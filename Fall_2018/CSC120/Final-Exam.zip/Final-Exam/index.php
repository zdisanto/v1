<!DOCTYPE html>
<html lang="en">
<head>
<title>Final Exam</title>
<link rel="stylesheet" type="text/css" href="finalStyles.css">
<meta charset="utf-8">
</head>
<body>
<header>
  <h1>Zo DiSanto's Final Exam</h1>
</header>

<nav>
  <ul>
     <li><a href="MyJavaScriptPage.php">JavaScript Page</a></li>
     <li><a href="ContactPage.php">Contact Page</a></li>
     <li><a href="ProcessContactInfoPage.php">Process Contact Page</a></li>
  </ul>
</nav>
<main>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Integer volutpat tempor egestas.
Sed sit amet finibus nisi. Nam nec rhoncus leo, id molestie metus. Ut rutrum laoreet placerat.
Ut volutpat, lectus non mollis efficitur, est nisl iaculis lectus, sed hendrerit turpis nulla quis nisl.
 Donec nec aliquam velit, sit amet iaculis magna. Fusce vel nulla vulputate, fermentum purus a, iaculis augue.
 Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam accumsan dignissim sapien, in faucibus justo scelerisque in.
 Nullam cursus leo sed luctus faucibus. Vestibulum eget sapien ut orci ornare sodales vitae auctor enim.
 Cras mollis consequat augue, sit amet lacinia mi tincidunt in.
 Pellentesque ut eleifend libero. Ut nec pellentesque arcu, a auctor erat. Duis posuere dictum magna vel bibendum.
Quisque molestie risus ultrices ullamcorper tincidunt.</p>
<p><!--Place an unordered list below here of your classes for this last semester.-->
	<ul>
		<li>Ant 111</li>
		<li>CSC 120</li>
		<li>HIS 100</li>
		<li>PSY 280</li>
	</ul>
</p>
</main>

<footer>
  <small><i>Copyright &copy; 2018 Zo DiSanto</i></small>
</footer>

</body>
</html>
